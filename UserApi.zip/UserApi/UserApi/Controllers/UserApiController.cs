﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using UserApi.Core;
using UserApi.Core.Models;
using UserApi.Core.Output;

namespace UserApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserApiController : ControllerBase
    {
        private IUnitOfWork _unitOfWork = null;
        private readonly ILogger<UserApiController> _logger;

        public UserApiController(ILogger<UserApiController> logger, IUnitOfWork unitOfWork)
        {
            _logger = logger;
            _unitOfWork = unitOfWork;
        }

        [HttpGet]
        public async Task<IEnumerable<User>> GetUserData()
        {
            var users = await _unitOfWork.Users.GetAllUserAsync();
            return users.ToList();
        }

        [HttpGet("GetUserById/{id}")]
        public async Task<ActionResult<UserDataOutput>> GetUserById(int id)
        {
            var users = await _unitOfWork.Users.GetUserByIdAsync(id);
            var todos = await _unitOfWork.Todos.GetTodoByUserIdAsync(id);
            var posts = await _unitOfWork.Posts.GetPostByUserIdAsync(id);
            var comments = await _unitOfWork.Comments.GetCommentsByPost(posts);

            posts.ToList().ForEach(d =>
            {
                d.Comments = comments.Where(w => w.postId == d.id).ToList();
            });
            var album = await _unitOfWork.Albums.GetAlbumByUserIdAsync(id);
            var photos = await _unitOfWork.Photos.GetPhotosByAlbum(album);

            album.ToList().ForEach(d =>
            {
                d.Photos = photos.Where(w => w.albumId == d.id).ToList();
            });
            UserDataOutput userDataOutput = new UserDataOutput()
            {
                UserDetails = users,
                Todos = todos.ToList(),
                Posts = posts.ToList(),
                Albums = album.ToList()
            };
            return userDataOutput;
        }

        [HttpGet("GetUserBySearchText/{text}")]
        public async Task<UserDataOutput> GetUserBySearchText(string text)
        {
            int id = 0;
            var user = await _unitOfWork.Users.GetUserBySearchTextAsync(text);
            id = user?.id ?? 0;

            var todos = await _unitOfWork.Todos.GetTodoByUserIdAsync(user.id);

            var posts = await _unitOfWork.Posts.GetPostByUserIdAsync(id);

            var comments = await _unitOfWork.Comments.GetCommentsByPost(posts);

            posts.ToList().ForEach(d =>
            {
                d.Comments = comments.Where(w => w.postId == d.id).ToList();
            });

            var album = await _unitOfWork.Albums.GetAlbumByUserIdAsync(id);

            var photos = await _unitOfWork.Photos.GetPhotosByAlbum(album);

            album.ToList().ForEach(d =>
            {
                d.Photos = photos.Where(w => w.albumId == d.id).ToList();
            });

            UserDataOutput userDataOutput = new UserDataOutput()
            {
                UserDetails = user,
                Todos = todos.ToList(),
                Posts = posts.ToList(),
                Albums = album.ToList()
            };
            return userDataOutput;
        }
        [HttpGet("GetUsersBySearchText/{text}")]
        public async Task<IEnumerable<UserDataOutput>> GetUsersBySearchText(string text)
        {
            List<UserDataOutput> usersDataOutput = null;
            int id = 0;
            var users = await _unitOfWork.Users.GetUsersBySearchTextAsync(text);
            if (users != null)
            {
                usersDataOutput = new List<UserDataOutput>();
                foreach (var user in users)
                {
                    id = user?.id ?? 0;

                    var todos = await _unitOfWork.Todos.GetTodoByUserIdAsync(id);
                    var posts = await _unitOfWork.Posts.GetPostByUserIdAsync(id);
                    var comments = await _unitOfWork.Comments.GetCommentsByPost(posts);
                    posts.ToList().ForEach(d =>
                    {
                        d.Comments = comments.Where(w => w.postId == d.id).ToList();
                    });
                    var album = await _unitOfWork.Albums.GetAlbumByUserIdAsync(id);
                    var photos = await _unitOfWork.Photos.GetPhotosByAlbum(album);
                    album.ToList().ForEach(d =>
                    {
                        d.Photos = photos.Where(w => w.albumId == d.id).ToList();
                    });
                    UserDataOutput udo = new UserDataOutput()
                    {
                        UserDetails = user,
                        Todos = todos.ToList(),
                        Posts = posts.ToList(),
                        Albums = album.ToList()
                    };
                    usersDataOutput.Add(udo);
                }
            }            
            return usersDataOutput;
        }

        [HttpGet("GetUserByGeoLocation/{lat}/{lng}/{distance}")]
        public async Task<UserDataOutput> GetUserByGeoLocation(string lat, string lng, string distance)
        {
            int id = 0;
            var user = await _unitOfWork.Users.GetUserByGeoLocation(lat, lng, distance);
            id = user?.id ?? 0;

            var todos = await _unitOfWork.Todos.GetTodoByUserIdAsync(id);

            var posts = await _unitOfWork.Posts.GetPostByUserIdAsync(id);

            var comments = await _unitOfWork.Comments.GetCommentsByPost(posts);

            posts.ToList().ForEach(d =>
            {
                d.Comments = comments.Where(w => w.postId == d.id).ToList();
            });

            var album = await _unitOfWork.Albums.GetAlbumByUserIdAsync(id);

            var photos = await _unitOfWork.Photos.GetPhotosByAlbum(album);

            album.ToList().ForEach(d =>
            {
                d.Photos = photos.Where(w => w.albumId == d.id).ToList();
            });

            UserDataOutput userDataOutput = new UserDataOutput()
            {
                UserDetails = user,
                Todos = todos.ToList(),
                Posts = posts.ToList(),
                Albums = album.ToList()
            };
            return userDataOutput;
        }
        [HttpGet("GetUsersByGeoLocation/{lat}/{lng}/{distance}")]
        public async Task<IEnumerable<UserDataOutput>> GetUsersByGeoLocation(string lat, string lng, string distance)
        {
            List <UserDataOutput> usersDataOutput = null;
            int id = 0;
            var users = await _unitOfWork.Users.GetUsersByGeoLocation(lat, lng, distance);
            if (users != null)
            {
                usersDataOutput = new List<UserDataOutput>();
                foreach (var user in users)
                {
                    id = user?.id ?? 0;
                    var todos = await _unitOfWork.Todos.GetTodoByUserIdAsync(id);
                    var posts = await _unitOfWork.Posts.GetPostByUserIdAsync(id);
                    var comments = await _unitOfWork.Comments.GetCommentsByPost(posts);
                    posts.ToList().ForEach(d =>
                    {
                        d.Comments = comments.Where(w => w.postId == d.id).ToList();
                    });
                    var album = await _unitOfWork.Albums.GetAlbumByUserIdAsync(id);
                    var photos = await _unitOfWork.Photos.GetPhotosByAlbum(album);
                    album.ToList().ForEach(d =>
                    {
                        d.Photos = photos.Where(w => w.albumId == d.id).ToList();
                    });
                    UserDataOutput udo = new UserDataOutput()
                    {
                        UserDetails = user,
                        Todos = todos.ToList(),
                        Posts = posts.ToList(),
                        Albums = album.ToList()
                    };
                    usersDataOutput.Add(udo);
                }
            }
            return usersDataOutput;
        }

        [HttpGet("GetSummaryReport")]
        public async Task<SummaryReportOutput> GetSummaryReport()
        {
            var users = await _unitOfWork.Users.GetAllUserAsync();
            var posts = await _unitOfWork.Posts.GetAllPostAsync();
            var comments = await _unitOfWork.Comments.GetAllCommentsAsync();

            SummaryReportOutput summaryReportOutput = new SummaryReportOutput()
            {
                NoOfUsers = users.Count(),
                AvgPostPerUser = posts.Count() / users.Count(),
                AvgCommentsPerPost = comments.Count()/ posts.Count()
            };
            return summaryReportOutput;
        }
    }
}
