﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace UserApi.Data
{
    public interface IGenericRepository<T> where T:class
    {
        //Task<T> GetByIdAsync(int id);
        Task<IEnumerable<T>> GetAllAsync(string url);
    }
}
