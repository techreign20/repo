﻿using Polly;
using RestSharp;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using UserApi.Data;

namespace UserApi.Data
{
    public class GenericRepository<T> : IGenericRepository<T> where T : class
    {
        private const int maxRetryAttempts = 10;
        private TimeSpan pauseBetweenFailures = TimeSpan.FromSeconds(5);
        private RestClient client = null;
        private string apiUrl = "https://jsonplaceholder.typicode.com/";

        public async Task<IEnumerable<T>> GetAllAsync(string url)
        {
            string URL = apiUrl + url;
            client = new RestClient(URL);
            RestRequest request = new RestRequest();
            var retryPolicy = Policy
           .Handle<System.Net.Http.HttpRequestException>()
           .WaitAndRetryAsync(maxRetryAttempts, i => pauseBetweenFailures);

            return await retryPolicy.ExecuteAsync(async () =>
            {
                return await client.GetAsync<List<T>>(request);
            });
        }
    }
}
