﻿using System;

namespace UserApi.Entity
{
    public class Class1
    {
    }
}
