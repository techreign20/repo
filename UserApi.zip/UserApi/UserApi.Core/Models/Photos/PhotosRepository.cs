﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UserApi.Data;

namespace UserApi.Core.Models
{
    public class PhotosRepository : GenericRepository<Photos>, IPhotosRepository
    {
        public async Task<IEnumerable<Photos>> GetPhotosByAlbum(IEnumerable<Album> albums)
        {
            List<int> albumIds =  albums.Select(s => s.id).ToList();
            var photos = await base.GetAllAsync("photos");
            return photos.Where(w => albumIds.Contains(w.albumId)).ToList();
        }
    }
}
