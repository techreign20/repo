﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using UserApi.Data;

namespace UserApi.Core.Models
{
    public interface IPhotosRepository
    {
        /// <summary>
        /// Returns the photos for the supplied input albums
        /// </summary>
        /// <param name="albums">Album list</param>
        /// <returns>Photo list for the supplied album list</returns>
        Task<IEnumerable<Photos>> GetPhotosByAlbum(IEnumerable<Album> albums);
    }
}
