﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UserApi.Data;

namespace UserApi.Core.Models
{
    public class TodosRepository : GenericRepository<Todos>, ITodosRepository
    {
        public async Task<IEnumerable<Todos>> GetTodoByUserIdAsync(int userId)
        {
            var todos = await base.GetAllAsync("todos");
            return todos.Where(w => w.userId == userId).ToList();
        }
    }
}
