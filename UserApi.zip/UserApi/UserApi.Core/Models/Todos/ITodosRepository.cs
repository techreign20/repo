﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using UserApi.Data;

namespace UserApi.Core.Models
{
    public interface ITodosRepository: IGenericRepository<Todos>
    {
        /// <summary>
        /// Returns the todos for the input user id
        /// </summary>
        /// <param name="userId">User id</param>
        /// <returns>Todo list for the input user id</returns>
        Task<IEnumerable<Todos>> GetTodoByUserIdAsync(int userId);
    }
}
