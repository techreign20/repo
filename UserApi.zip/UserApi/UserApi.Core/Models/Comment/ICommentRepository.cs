﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using UserApi.Data;

namespace UserApi.Core.Models
{
    public interface ICommentRepository
    {
        /// <summary>
        /// Returns all the comments
        /// </summary>
        /// <returns></returns>
        Task<IEnumerable<Comment>> GetAllCommentsAsync();
        /// <summary>
        /// Returns the comments for the supplied input posts
        /// </summary>
        /// <param name="posts">Post list</param>
        /// <returns>Comment list for the supplied post list</returns>
        Task<IEnumerable<Comment>> GetCommentsByPost(IEnumerable<Post> posts);
    }
}
