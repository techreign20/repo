﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UserApi.Data;

namespace UserApi.Core.Models
{
    public class CommentRepository : GenericRepository<Comment>, ICommentRepository
    {
        public async Task<IEnumerable<Comment>> GetAllCommentsAsync()
        {
            return await base.GetAllAsync("comments");
        }

        public async Task<IEnumerable<Comment>> GetCommentsByPost(IEnumerable<Post> posts)
        {
            List<int> postIds = posts.Select(s => s.id).ToList();
            var comments = await base.GetAllAsync("comments");
            return comments.Where(w => postIds.Contains(w.postId)).ToList();
        }
    }
}
