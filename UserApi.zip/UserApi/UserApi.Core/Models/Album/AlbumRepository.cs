﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UserApi.Data;

namespace UserApi.Core.Models
{
    public class AlbumRepository : GenericRepository<Album>, IAlbumRepository
    {
        public async Task<IEnumerable<Album>> GetAlbumByUserIdAsync(int userId)
        {
            var albums = await base.GetAllAsync("albums");
            return albums.Where(w => w.userId == userId).ToList();
        }
    }
}
