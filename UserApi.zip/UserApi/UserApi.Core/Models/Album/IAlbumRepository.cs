﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using UserApi.Data;

namespace UserApi.Core.Models
{
    public interface IAlbumRepository 
    {
        /// <summary>
        /// Returns the list of album for the supplied user id
        /// </summary>
        /// <param name="userId">User id</param>
        /// <returns>List of albums for the input user id</returns>
        Task<IEnumerable<Album>> GetAlbumByUserIdAsync(int userId);
    }
}
