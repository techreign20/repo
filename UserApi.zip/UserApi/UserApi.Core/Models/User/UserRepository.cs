﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using UserApi.Data;
using System.Linq;

namespace UserApi.Core.Models

{
    public class UserRepository : GenericRepository<User>, IUserRepository
    {
        public async Task<IEnumerable<User>> GetAllUserAsync()
        {
            return await base.GetAllAsync("users");
        }
        public async Task<User> GetUserByIdAsync(int id)
        {
            var users = await base.GetAllAsync("users") ;
            return users.Where(w => w.id == id).FirstOrDefault();
        }

        public async Task<User> GetUserBySearchTextAsync(string searchText)
        {
            var users = await base.GetAllAsync("users");
            var user = users.Where(w => w.name.ToLower() == searchText.ToLower() || w.email.ToLower() == searchText.ToLower() || w.address.city.ToLower() == searchText.ToLower()).FirstOrDefault();
            return user;
        }
        public async Task<IEnumerable<User>> GetUsersBySearchTextAsync(string searchText)
        {
            var users = await base.GetAllAsync("users");
            var userList = users.Where(w => w.name.ToLower().Contains(searchText.ToLower()) || w.email.ToLower().Contains(searchText.ToLower()) || w.address.city.ToLower().Contains(searchText.ToLower())).ToList();
            return userList;
        }
        private double GetDistanceBetweenPoints(double lat1, double long1, double lat2, double long2)
        {
            double distance = 0;

            double dLat = (lat2 - lat1) / 180 * Math.PI;
            double dLong = (long2 - long1) / 180 * Math.PI;

            double a = Math.Sin(dLat / 2) * Math.Sin(dLat / 2)
                        + Math.Cos(lat2) * Math.Sin(dLong / 2) * Math.Sin(dLong / 2);
            double c = 2 * Math.Atan2(Math.Sqrt(a), Math.Sqrt(1 - a));

            //Calculate radius of earth
            // For this you can assume any of the two points.
            double radiusE = 6378135; // Equatorial radius, in metres
            double radiusP = 6356750; // Polar Radius

            //Numerator part of function
            double nr = Math.Pow(radiusE * radiusP * Math.Cos(lat1 / 180 * Math.PI), 2);
            //Denominator part of the function
            double dr = Math.Pow(radiusE * Math.Cos(lat1 / 180 * Math.PI), 2)
                            + Math.Pow(radiusP * Math.Sin(lat1 / 180 * Math.PI), 2);
            double radius = Math.Sqrt(nr / dr);

            //Calaculate distance in metres.
            distance = radius * c;
            return distance;
        }
        /// <summary>
        /// Returns the user whose geo location and input parameter latitude/longitude difference is greater than or equal to the 
        /// input parameter distance
        /// </summary>
        /// <param name="lat">Latitude to calculate distance with user geo location</param>
        /// <param name="lng">Longitude to calculate distance with user geo location</param>
        /// <param name="distance">Minimum distance between user geo location and input latitude/longitude</param>
        /// <returns>Matching user with minimum distance as the supplied input disance</returns>
        public async Task<User> GetUserByGeoLocation(string lat, string lng, string distance)
        {
            var allUsers = await GetAllUserAsync();
            foreach (var user in allUsers)
            {
                var calculatedDistance = GetDistanceBetweenPoints
                    (
                         Convert.ToDouble(user.address.geo.lat),
                         Convert.ToDouble(user.address.geo.lng),
                         Convert.ToDouble(lat),
                         Convert.ToDouble(lng)
                    );
                if (calculatedDistance >= Convert.ToDouble(distance))
                    return user;
            }
            return null;
        }
        /// <summary>
        /// Returns the list of users whose geo location and input parameter latitude/longitude difference is greater than or equal to the 
        /// input parameter distance
        /// </summary>
        /// <param name="lat">Latitude to calculate distance with user geo location</param>
        /// <param name="lng">Longitude to calculate distance with user geo location</param>
        /// <param name="distance">Minimum distance between user geo location and input latitude/longitude</param>
        /// <returns>Matching users with minimum distance as the supplied input disance</returns>
        public async Task<IEnumerable<User>> GetUsersByGeoLocation(string lat, string lng, string distance)
        {
            var allUsers = await GetAllUserAsync();
            List<User> users = new List<User>();
            foreach (var user in allUsers)
            {
                var calculatedDistance = GetDistanceBetweenPoints
                    (
                         Convert.ToDouble(user.address.geo.lat),
                         Convert.ToDouble(user.address.geo.lng),
                         Convert.ToDouble(lat),
                         Convert.ToDouble(lng)
                    );
                if (calculatedDistance >= Convert.ToDouble(distance))
                    users.Add(user);
            }
            return users;
        }
    }
}
