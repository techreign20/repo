﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using UserApi.Data;

namespace UserApi.Core.Models
{
    public interface IUserRepository
    {
        /// <summary>
        /// Returns all the users
        /// </summary>
        /// <returns>All user list</returns>
        Task<IEnumerable<User>> GetAllUserAsync();
        /// <summary>
        /// Returns the user for the input user id
        /// </summary>
        /// <param name="id">User id</param>
        /// <returns>Matching user of the input user id</returns>
        Task<User> GetUserByIdAsync(int id);
        /// <summary>
        /// Searches for the user with name or email or city
        /// </summary>
        /// <param name="searchText">Search string for user name or email or city</param>
        /// <returns>Matching user by name or email or city</returns>
        Task<User> GetUserBySearchTextAsync(string searchText);
        /// <summary>
        /// Returns the list of users for the input user id
        /// </summary>
        /// <param name="searchText">Search string for user name or email or city</param>
        /// <returns>Matching users by name or email or city</returns>
        Task<IEnumerable<User>> GetUsersBySearchTextAsync(string searchText);
        /// <summary>
        /// Returns the user whose geo location and input parameter latitude/longitude difference is greater than or equal to the 
        /// input parameter distance
        /// </summary>
        /// <param name="lat">Latitude to calculate distance with user geo location</param>
        /// <param name="lng">Longitude to calculate distance with user geo location</param>
        /// <param name="distance">Minimum distance between user geo location and input latitude/longitude</param>
        /// <returns>Matching user with minimum distance as the supplied input disance</returns>
        Task<User> GetUserByGeoLocation(string lat, string lng, string distance);
        /// <summary>
        /// Returns the list of users whose geo location and input parameter latitude/longitude difference is greater than or equal to the 
        /// input parameter distance
        /// </summary>
        /// <param name="lat">Latitude to calculate distance with user geo location</param>
        /// <param name="lng">Longitude to calculate distance with user geo location</param>
        /// <param name="distance">Minimum distance between user geo location and input latitude/longitude</param>
        /// <returns>Matching users with minimum distance as the supplied input disance</returns>
        Task<IEnumerable<User>> GetUsersByGeoLocation(string lat, string lng, string distance);
    }
}
