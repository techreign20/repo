﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using UserApi.Data;
using System.Linq;

namespace UserApi.Core.Models
{
    public class PostRepository : GenericRepository<Post>, IPostRepository
    {
        public async Task<IEnumerable<Post>> GetAllPostAsync()
        {
            return await base.GetAllAsync("posts");
        }

        public async Task<IEnumerable<Post>> GetPostByUserIdAsync(int userId)
        {
            var posts = await base.GetAllAsync("posts");
            return posts.Where(w => w.userId == userId).ToList();
        }
    }
}
