﻿using System.Collections.Generic;
using System.Threading.Tasks;
using UserApi.Data;

namespace UserApi.Core.Models
{
    public interface IPostRepository
    {
        /// <summary>
        /// Returns all the posts
        /// </summary>
        /// <returns>All the post list</returns>
        Task<IEnumerable<Post>> GetAllPostAsync();
        /// <summary>
        /// Returns the posts for the input user id
        /// </summary>
        /// <param name="userId">User id</param>
        /// <returns>Post list for the input user id</returns>
        Task<IEnumerable<Post>> GetPostByUserIdAsync(int userId);
    }
}
