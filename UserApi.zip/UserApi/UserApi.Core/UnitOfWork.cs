﻿using System;
using System.Collections.Generic;
using System.Text;
using UserApi.Core.Models;

namespace UserApi.Core
{
    public class UnitOfWork : IUnitOfWork
    {
        private UserRepository _userRepository;
        private TodosRepository _todosRepository;
        private PostRepository _postRepository;
        private CommentRepository _commentRepository;
        private AlbumRepository _albumRepository;
        private PhotosRepository _photosRepository;
        public IUserRepository Users => _userRepository = _userRepository ?? new UserRepository();

        public ITodosRepository Todos => _todosRepository = _todosRepository ?? new TodosRepository();

        public IPostRepository Posts => _postRepository = _postRepository ?? new PostRepository();

        public ICommentRepository Comments => _commentRepository = _commentRepository?? new CommentRepository();

        public IAlbumRepository Albums => _albumRepository = _albumRepository ?? new AlbumRepository();

        public IPhotosRepository Photos => _photosRepository = _photosRepository?? new PhotosRepository();

        public void Dispose()
        {
            
        }
    }
}
