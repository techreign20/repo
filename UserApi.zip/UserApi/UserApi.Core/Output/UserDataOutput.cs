﻿using System;
using System.Collections.Generic;
using System.Text;
using UserApi.Core.Models;

namespace UserApi.Core.Output
{
    public class UserDataOutput
    {
        public User UserDetails { get; set; }
        public List<Todos> Todos { get; set; }
        public List<Post> Posts { get; set; }
        public List<Album> Albums { get; set; }
    }
}
