﻿using System;
using System.Collections.Generic;
using System.Text;

namespace UserApi.Core.Output
{
   public class SummaryReportOutput
    {
        public int NoOfUsers { get; set; }
        public int AvgPostPerUser { get; set; }
        public int AvgCommentsPerPost { get; set; }

    }
}
