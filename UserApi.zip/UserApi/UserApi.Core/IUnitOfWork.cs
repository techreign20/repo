﻿using System;
using System.Collections.Generic;
using System.Text;
using UserApi.Core.Models;

namespace UserApi.Core
{
    public interface IUnitOfWork: IDisposable
    {
        IUserRepository Users { get; }
        ITodosRepository Todos { get; }
        IPostRepository Posts { get; }

        ICommentRepository Comments { get; }
        IAlbumRepository Albums { get; }

        IPhotosRepository Photos { get; }

    }
}
